#include <iostream>
#include "fib_market_api.h"

int main() {
    // Dados de mercado simulados (movimento de alta)
    double precoBaixo = 20.00;  // Swing Low
    double precoAlto  = 30.00;  // Swing High
    int tendencia = 1;          // 1 = alta

    std::cout << "Iniciando predicao de mercado via API Fibonacci...\n\n";

    // Chamada da funcao exportada pela biblioteca compartilhada
    calcularRetracoes(precoBaixo, precoAlto, tendencia);

    return 0;
}
