
#include <iostream>
#include <limits>
#include "CalculadoraFibonacci.h"

// Lê um número inteiro do teclado, repetindo se o usuário digitar fora do previsto
int lerInteiro(const char* mensagem) {
    int valor;
    while (true) {
        std::cout << mensagem;
        if (std::cin >> valor) return valor;

        if (std::cin.eof()) return -1;   
        std::cin.clear();                                                    // limpa o erro
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // descarta a linha
        std::cout << "Entrada invalida. Digite um numero inteiro.\n";
    }
}

int main() {
    CalculadoraFibonacci calc;   // usa o construtor padrão 

    int opcao = -1;
    do {
        std::cout << "\n===== Calculadora de Fibonacci =====\n"
                  << "1) Recursivo\n"
                  << "2) Iterativo\n"
                  << "3) Binet\n"
                  << "4) Comparar os tres metodos\n"
                  << "0) Sair\n";
        opcao = lerInteiro("Escolha: ");
        if (opcao == 0 || std::cin.eof()) break;
        if (opcao < 1 || opcao > 4) {
            std::cout << "Opcao invalida.\n";
            continue;
        }

        int n = lerInteiro("Valor de n (0 a 92): ");
        if (n < 0 || n > 92) {
            std::cout << "n fora do intervalo.\n";
            continue;
        }

        switch (opcao) {
            case 1:
                if (n > 40) {
                    std::cout << "Recursivo com n tao grande demoraria muito. Use nessa função n <= 40.\n";
                } else {
                    std::cout << "F(" << n << ") = " << calc.recursivo(n) << "\n";
                }
                break;
            case 2:
                std::cout << "F(" << n << ") = " << calc.iterativo(n) << "\n";
                break;
            case 3: {
                long long r = calc.binet(n);
                if (r == -1) {
                    std::cout << "Binet e impreciso para n = " << n
                              << " (limite de confianca: " << calc.getLimiteBinet() << ").\n";
                } else {
                    std::cout << "F(" << n << ") = " << r << "\n";
                }
                break;
            }
            case 4:
                calc.compararMetodos(n);
                break;
        }
    } while (true);

    std::cout << "Encerrando Programa...\n";
    return 0;
}