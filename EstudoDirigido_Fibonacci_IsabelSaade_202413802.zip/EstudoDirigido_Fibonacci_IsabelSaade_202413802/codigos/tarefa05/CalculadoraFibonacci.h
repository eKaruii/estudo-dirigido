
#pragma once   // evita que este arquivo seja incluído duas vezes na compilação

class CalculadoraFibonacci {
private:
    // Dados internos. Ficam escondidos (private) para que ninguém de
    // fora mexa neles diretamente e quebre a classe.
    int limiteBinet_;   // maior n em que confiamos no resultado de Binet

    // Maior n cujo Fibonacci cabe em um long long (F(92)). Depois disso o número estoura e vira lixo.
    static constexpr int N_MAXIMO = 92;

    // Ajudante interno: calcula Binet SEM verificar o limite.
    // Usado só para mostrar, na tabela, o erro de Binet.
    long long binetBruto(int n) const;

public:
    // cria a calculadora. Se não passar nada, o limite é 70.
    explicit CalculadoraFibonacci(int limiteBinet = 70);

    // Qual é o limite configurado? ("const" = só lê, não altera nada)
    int getLimiteBinet() const;

    // Os três jeitos de calcular. Todos são "const" porque apenas
    // consultam/calculam, sem alterar o objeto.
    // Se n for inválido (negativo ou maior que 92), devolvem -1.
    long long recursivo(int n) const;
    long long iterativo(int n) const;

    // Devolve -1 (valor especial) quando Binet é impreciso, isto é,
    // quando n passa do limite. (Não usamos 0 porque F(0) também é 0.)
    long long binet(int n) const;

    // Imprime uma tabela comparando os três métodos para o mesmo n.
    void compararMetodos(int n) const;
};