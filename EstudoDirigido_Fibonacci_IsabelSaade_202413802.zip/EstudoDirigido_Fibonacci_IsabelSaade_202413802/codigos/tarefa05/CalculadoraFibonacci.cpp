// CalculadoraFibonacci.cpp  (a "implementação" da classe)
// Aqui está o código de verdade de cada operação anunciada no .h.
// O "CalculadoraFibonacci::" na frente de cada função diz ao
// compilador: "esta função pertence à classe".
#include "CalculadoraFibonacci.h"

#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
#include <chrono>
#include <cstdlib>

// LISTA DE INICIALIZAÇÃO DE MEMBROS.
CalculadoraFibonacci::CalculadoraFibonacci(int limiteBinet)
    : limiteBinet_(limiteBinet) {
}

int CalculadoraFibonacci::getLimiteBinet() const {
    return limiteBinet_;
}

// a função chama ela mesma (igual à Tarefa 02)
long long CalculadoraFibonacci::recursivo(int n) const {
    if (n < 0 || n > N_MAXIMO) return -1;   // n inválido
    if (n == 0 || n == 1) return n;         // casos base
    // chama a própria função do objeto, duas vezes, com n menores
    return recursivo(n - 1) + recursivo(n - 2);
}

// laço simples, guardando só os dois últimos valores
long long CalculadoraFibonacci::iterativo(int n) const {
    if (n < 0 || n > N_MAXIMO) return -1;
    if (n == 0) return 0;

    long long anterior = 0, atual = 1;
    for (int i = 2; i <= n; ++i) {
        long long proximo = anterior + atual;
        anterior = atual;
        atual = proximo;
    }
    return atual;
}

// faz a conta sem checar o limite (uso interno).
long long CalculadoraFibonacci::binetBruto(int n) const {
    const double raiz5 = std::sqrt(5.0);
    const double phi = (1.0 + raiz5) / 2.0;
    const double psi = (1.0 - raiz5) / 2.0;
    return std::llround((std::pow(phi, n) - std::pow(psi, n)) / raiz5);
}

// só responde se confiar no resultado.
long long CalculadoraFibonacci::binet(int n) const {
    if (n < 0 || n > N_MAXIMO) {
        return -1;
    }

    // Limite de segurança configurado no construtor.
    if (n > limiteBinet_) {
        return -1;
    }

    // Calcula o resultado usando a fórmula de Binet.
    long long resultado = binetBruto(n);

    // Compara com o resultado exato do método iterativo.
    // Se houver divergência, considera o resultado impreciso.
    if (resultado != iterativo(n)) {
        return -1;
    }

    return resultado;
}


// mostra resultado, tempo e situação de cada método.
void CalculadoraFibonacci::compararMetodos(int n) const {
    if (n < 0 || n > N_MAXIMO) {
        std::cout << "n invalido (use de 0 a " << N_MAXIMO << ").\n";
        return;
    }

    // Referência correta, para comparar os outros métodos
    const long long certo = iterativo(n);

    std::cout << "\nComparacao dos metodos para n = " << n << "\n";
    std::cout << std::string(66, '-') << "\n";
    std::cout << std::left  << std::setw(12) << "Metodo"
              << std::right << std::setw(22) << "Resultado"
              << std::setw(14) << "Tempo (ms)"
              << "  Situacao\n";
    std::cout << std::string(66, '-') << "\n";
    std::cout << std::fixed << std::setprecision(4);

    // --- Recursivo ---
    // Acima de n = 40 a recursão demora demais, então pulamos.
    std::cout << std::left << std::setw(12) << "Recursivo" << std::right;
    if (n <= 40) {
        auto t0 = std::chrono::steady_clock::now();
        long long r = recursivo(n);
        auto t1 = std::chrono::steady_clock::now();
        std::chrono::duration<double, std::milli> ms = t1 - t0;
        std::cout << std::setw(22) << r << std::setw(14) << ms.count()
                  << (r == certo ? "  correto" : "  ERRADO") << "\n";
    } else {
        std::cout << std::setw(22) << "-" << std::setw(14) << "-"
                  << "  pulado (demoraria demais)\n";
    }

    // --- Iterativo ---
    {
        auto t0 = std::chrono::steady_clock::now();
        long long r = iterativo(n);
        auto t1 = std::chrono::steady_clock::now();
        std::chrono::duration<double, std::milli> ms = t1 - t0;
        std::cout << std::left << std::setw(12) << "Iterativo" << std::right
                  << std::setw(22) << r << std::setw(14) << ms.count()
                  << "  correto (referencia)\n";
    }

    // Binet
    // Usamos o "bruto" para mostrar o valor mesmo quando impreciso,
    // e o binet() normal para saber se a classe confia nele.
    {
        auto t0 = std::chrono::steady_clock::now();
        long long r = binetBruto(n);
        auto t1 = std::chrono::steady_clock::now();
        std::chrono::duration<double, std::milli> ms = t1 - t0;

        std::cout << std::left << std::setw(12) << "Binet" << std::right
                  << std::setw(22) << r << std::setw(14) << ms.count();
        if (r == certo) {
            std::cout << "  correto";
        } else {
            std::cout << "  IMPRECISO (erro de " << std::llabs(r - certo) << ")";
        }
        std::cout << "\n";

        if (binet(n) == -1) {
            std::cout << "(binet(" << n << ") devolve -1: acima do limite de confianca "
                      << limiteBinet_ << ")\n";
        }
    }
    std::cout << "\n";
}