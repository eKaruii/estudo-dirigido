// Tarefa 03 - Modelo Iterativo
/* calcular Fibonacci com um simples laço, começando do começo 
(0, 1, 1, 2, 3, 5...) e indo até n.
Depois, comparar o tempo com a versão recursiva. */

#include <iostream>
#include <string>
#include <iomanip>
#include <chrono>     //cronômetro

// prototipos
long long fibonacciIterativo(int n);
long long fibonacciRecursivo(int n);

int main() {
    // Valores de n testados
    const int valores[] = {10, 20, 30, 35, 40};

    // tabela
    std::cout << std::fixed << std::setprecision(6);
    std::cout << std::setw(5)  << "n"
              << std::setw(16) << "F(n)"
              << std::setw(18) << "iterativo (ms)"
              << std::setw(18) << "recursivo (ms)" << "\n";
    std::cout << std::string(57, '-') << "\n";

    for (int n : valores) {
        // Cronômetro: anoto a hora, executa, anoto a hora de novo, a diferença entre as duas horas é o tempo gasto.
        auto t0 = std::chrono::steady_clock::now();     // início do iterativo
        long long fi = fibonacciIterativo(n);
        auto t1 = std::chrono::steady_clock::now();     // fim do iterativo e início do recursivo
        long long fr = fibonacciRecursivo(n);
        auto t2 = std::chrono::steady_clock::now();     // fim do recursivo

        // Converte para milissegundos (ms)
        std::chrono::duration<double, std::milli> tIter = t1 - t0;
        std::chrono::duration<double, std::milli> tRec  = t2 - t1;

        std::cout << std::setw(5)  << n
                  << std::setw(16) << fi
                  << std::setw(18) << tIter.count()
                  << std::setw(18) << tRec.count();

        // os dois métodos devem dar o mesmo resultado
        if (fi != fr) std::cout << "  <-- RESULTADOS DIFEREM!";
        std::cout << "\n";
    }
    return 0;
}

// VERSÃO ITERATIVA (bottom-up = "de baixo para cima")
// Em vez de começar de F(n) e descer, começo de F(0) e subir até F(n).
long long fibonacciIterativo(int n) {
    if (n == 0) return 0;   // caso especial: F(0) = 0

    long long anterior = 0;   // F(0)
    long long atual = 1;      // F(1)

    // Cada volta do laço avança na sequência, somando os dois últimos números para formar o próximo.
    for (int i = 2; i <= n; ++i) {
        long long proximo = anterior + atual;   // soma os dois últimos
        anterior = atual;                       // anda uma casa
        atual = proximo;
    }
    return atual;   // no final guarda F(n)
}

long long fibonacciRecursivo(int n) {
    if (n == 0 || n == 1) return n;
    return fibonacciRecursivo(n - 1) + fibonacciRecursivo(n - 2);
}

/*
O iterativo é mais rápido porque calcula os números de Fibonacci usando
um laço, guardando os dois últimos valores nas variáveis anterior e atual.
A cada repetição, ele soma esses valores para encontrar o próximo número
e atualiza as variáveis para continuar a sequência.

Já o recursivo chama a própria função várias vezes para calcular os
valores anteriores. Com isso, acaba repetindo cálculos que já foram feitos,
o que aumenta bastante o tempo de execução conforme n cresce.

Além disso, o iterativo utiliza apenas algumas variáveis auxiliares,
enquanto o recursivo precisa guardar as chamadas na pilha de memória.
Por isso, o iterativo tem complexidade de tempo O(n) e espaço auxiliar
O(1), enquanto o recursivo tem tempo O(2^n) e espaço de pilha O(n).

No código, uso o std::chrono para medir o tempo de cada método e comparar
os resultados. Assim, consigo observar na prática a diferença de desempenho
entre as duas formas de calcular Fibonacci.
*/