// Tarefa 02 - Modelo Recursivo
/* calcular Fibonacci do jeito "da definição":
F(n) = F(n-1) + F(n-2). A função chama ela mesma, cada vez 
com um número menor, até chegar em 0 ou 1.
Também contamos quantas vezes chegamos nesse "fim da linha".*/

#include <iostream>

// prototipo
long long fibonacciRecursivo(int n);

// CONTADOR GLOBAL: quantifica quantas vezes os casos base 
// são atingidos para n = 10, n = 20 e n = 30.
long long contadorCasosBase = 0;

int main() {
    //mostra F(0) até F(40)
    std::cout << "Valores de F(n) para n = 0..40:\n";
    for (int n = 0; n <= 40; ++n) {
        std::cout << "F(" << n << ") = " << fibonacciRecursivo(n) << "\n";
    }

    //conta os casos base para n = 10, 20 e 30
    std::cout << "\nCasos base atingidos:\n";
    const int testes[] = {10, 20, 30};
    for (int n : testes) {
        contadorCasosBase = 0;   // zera o contador antes de cada teste!
        long long resultado = fibonacciRecursivo(n);
        std::cout << "n = " << n << " -> F(n) = " << resultado
                  << " | casos base atingidos: " << contadorCasosBase << "\n";
    }
    return 0;
}

long long fibonacciRecursivo(int n) {
    // CASO BASE: F(0) = 0 e F(1) = 1 a recursão para.
    if (n == 0 || n == 1) {
        ++contadorCasosBase;   // anota que chegou no fim
        return n;              // como F(0)=0 e F(1)=1, devolver n já resolve
    }

    return fibonacciRecursivo(n - 1) + fibonacciRecursivo(n - 2);
}

/* A complexidade é O(2^n) porque, a cada chamada, a função faz
outras duas chamadas. Por exemplo, para calcular F(5), ela chama
F(4) e F(3), e essas funções também fazem novas chamadas.

Com isso, o número de chamadas aumenta bastante conforme o valor
de n cresce, fazendo com que a complexidade seja exponencial.

Isso também faz com que alguns cálculos sejam repetidos várias
vezes, como acontece com F(3), que pode ser calculada novamente
mesmo que já tenha sido calculada antes.

Já o uso da pilha de memória é O(n), porque cada chamada ocupa
um espaço na memória. A função continua fazendo chamadas até
chegar ao caso base e, depois, retorna os resultados. Como a
quantidade máxima de chamadas empilhadas depende de n, o espaço
utilizado cresce de forma linear.
*/