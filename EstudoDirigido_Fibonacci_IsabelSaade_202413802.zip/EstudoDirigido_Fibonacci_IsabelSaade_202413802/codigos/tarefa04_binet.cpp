
// Tarefa 04 - Fórmula de Binet e Investigação dos Pontos Críticos
// Calcular Fibonacci com uma fórmula "direta"
// (sem laço e sem recursão) e descobrir onde ela começa a errar.

// Parte 1 (4.1): implementar a fórmula de Binet
// Parte 2 (4.2): comparar com o iterativo e achar o n da falha
// Parte 3 (4.3): medir o tempo (a "ilusão" do O(1))
// Parte 4 (4.4): origem da fórmula (explicação nos comentários)

#include <iostream>
#include <iomanip>
#include <cmath>      // sqrt, pow, llround
#include <chrono>     // cronômetro
#include <cstdlib>    // std::llabs
#include <string>     // std::string

// Protótipos
long long fibonacciIterativo(int n);
long long fibonacciBinet(int n);
void experimentoPrecisao();
void experimentoTempo();

template <typename Funcao>
double medirNanosegundos(Funcao f, int n, int repeticoes);

int main() {
    experimentoPrecisao();
    experimentoTempo();

    return 0;
}

// ============================================================
// 4.1 - IMPLEMENTAÇÃO
// ============================================================

// Versão iterativa: resultado exato para 0 <= n <= 92,
// considerando um long long de 64 bits.
long long fibonacciIterativo(int n) {
    if (n == 0) return 0;
    if (n == 1) return 1;

    long long anterior = 0;
    long long atual = 1;

    for (int i = 2; i <= n; ++i) {
        long long proximo = anterior + atual;
        anterior = atual;
        atual = proximo;
    }

    return atual;
}

// Fórmula de Binet:
// F(n) = (phi^n - psi^n) / raiz(5)
//
// phi = (1 + raiz(5)) / 2  ~= 1.618...
// psi = (1 - raiz(5)) / 2  ~= -0.618...
//
// O resultado teórico é um número inteiro. Porém, como usamos
// double, podem ocorrer pequenas diferenças de arredondamento.
// Por isso, utilizamos std::llround para arredondar o resultado
// para o inteiro mais próximo.
long long fibonacciBinet(int n) {
    const double raiz5 = std::sqrt(5.0);
    const double phi = (1.0 + raiz5) / 2.0;
    const double psi = (1.0 - raiz5) / 2.0;

    double valor =
        (std::pow(phi, n) - std::pow(psi, n)) / raiz5;

    return std::llround(valor);
}

// ============================================================
// 4.2 - EXPERIMENTO DO PONTO B
// Precisão de ponto flutuante
// ============================================================

void experimentoPrecisao() {
    const int NMAX = 90;

    // Procura o primeiro n em que Binet apresenta um resultado
    // diferente da versão iterativa.
    int primeiraFalha = -1;

    for (int n = 0; n <= NMAX; ++n) {
        if (fibonacciBinet(n) != fibonacciIterativo(n)) {
            primeiraFalha = n;
            break;
        }
    }

    std::cout
        << "=== EXPERIMENTO B: PRECISAO DE PONTO FLUTUANTE ===\n\n";

    if (primeiraFalha == -1) {
        std::cout
            << "Binet acertou todos os valores ate n = "
            << NMAX << ".\n\n";
        return;
    }

    std::cout
        << "Binet acerta de n = 0 ate n = "
        << primeiraFalha - 1 << ".\n";

    std::cout
        << "A PRIMEIRA FALHA acontece em n = "
        << primeiraFalha << ".\n\n";

    // Mostra cinco valores antes da falha e alguns depois.
    int inicio = primeiraFalha - 5;
    int fim = primeiraFalha + 9;

    if (inicio < 0) inicio = 0;
    if (fim > NMAX) fim = NMAX;

    std::cout << std::setw(4) << "n"
              << std::setw(22) << "iterativo (certo)"
              << std::setw(22) << "Binet"
              << std::setw(14) << "diferenca"
              << "\n";

    std::cout << std::string(62, '-') << "\n";

    for (int n = inicio; n <= fim; ++n) {
        long long certo = fibonacciIterativo(n);
        long long binet = fibonacciBinet(n);

        long long diferenca = std::llabs(certo - binet);

        std::cout << std::setw(4) << n
                  << std::setw(22) << certo
                  << std::setw(22) << binet
                  << std::setw(14) << diferenca;

        if (diferenca != 0) {
            std::cout << "  <-- ERRO";
        }

        std::cout << "\n";
    }

    std::cout << "\n";
}

/*
POR QUE BINET ERRA?

A fórmula de Binet pode apresentar erros devido à precisão
limitada do tipo double, que possui aproximadamente 53 bits
de precisão significativa.

Como a fórmula utiliza a raiz quadrada de 5, um número
irracional, o computador precisa trabalhar com uma aproximação
desse valor. Isso também afeta o cálculo de phi e de sua
potência n.

Conforme n aumenta, pequenos erros de representação e
arredondamento podem se acumular e aumentar no resultado final.
Quando a diferença entre o resultado calculado e o inteiro
correto chega a aproximadamente 0,5 ou ultrapassa esse limite,
o std::llround pode arredondar para o inteiro errado.

O problema não ocorre simplesmente porque o número possui
mais de 15 ou 16 dígitos decimais. O que importa é a precisão
disponível para representar o resultado e o erro acumulado
durante os cálculos.

Por isso, comparamos Binet com a versão iterativa, que serve
como referência exata dentro do limite do tipo long long.

O primeiro valor de n em que ocorre a divergência deve ser
identificado experimentalmente, pois pode depender da
implementação das funções matemáticas e do ambiente de execução.

O std::llround não consegue corrigir um erro numérico que já
seja grande o suficiente para colocar o resultado do outro
lado do ponto médio entre dois inteiros.
*/

// ============================================================
// 4.3 - ANÁLISE DO PONTO A
// A ilusão do O(1)
// ============================================================

// Mede o tempo médio por chamada em nanossegundos.
//
// Alternamos a entrada entre n e n + 1 para reduzir a
// possibilidade de o compilador reutilizar um único resultado
// calculado antecipadamente. Portanto, cada medida representa
// a média das chamadas para esses dois valores próximos.
template <typename Funcao>
double medirNanosegundos(Funcao f, int n, int repeticoes) {
    volatile long long resultado = 0;

    auto inicio = std::chrono::steady_clock::now();

    for (int i = 0; i < repeticoes; ++i) {
        int entrada = n + (i % 2);
        resultado = f(entrada);
    }

    auto fim = std::chrono::steady_clock::now();

    // A leitura impede que o resultado seja simplesmente
    // descartado como uma variável não utilizada.
    (void)resultado;

    std::chrono::duration<double, std::nano> total = fim - inicio;

    return total.count() / repeticoes;
}

void experimentoTempo() {
    const int valores[] = {10, 20, 40, 60, 70};
    const int REPETICOES = 1000000;

    std::cout
        << "=== EXPERIMENTO A: TEMPO DE EXECUCAO ===\n";

    std::cout
        << "Media em nanossegundos por chamada.\n";

    std::cout
        << "Entrada alternada entre n e n + 1.\n\n";

    std::cout << std::fixed << std::setprecision(1);

    std::cout << std::setw(5) << "n"
              << std::setw(18) << "iterativo (ns)"
              << std::setw(16) << "Binet (ns)"
              << "\n";

    std::cout << std::string(39, '-') << "\n";

    for (int n : valores) {
        double tIter = medirNanosegundos(
            fibonacciIterativo, n, REPETICOES
        );

        double tBinet = medirNanosegundos(
            fibonacciBinet, n, REPETICOES
        );

        std::cout << std::setw(5) << n
                  << std::setw(18) << tIter
                  << std::setw(16) << tBinet
                  << "\n";
    }

    std::cout << "\n";
}

/*
ANÁLISE DO PONTO A: A ILUSÃO DO O(1)

A fórmula de Binet parece ter complexidade O(1) porque realiza
uma quantidade fixa de operações matemáticas no código.

Entretanto, isso não significa que cada operação tenha o custo
de uma soma simples. A função std::pow possui uma implementação
interna cujo custo depende da biblioteca matemática, do
processador e da precisão utilizada.

Na prática, o tempo medido pode ser aproximadamente constante
para os valores testados, mas isso não prova que o custo interno
seja rigorosamente independente de n.

Para números do tipo double, o tamanho da representação é fixo.
Porém, a precisão é limitada, e o resultado pode deixar de ser
correto conforme n aumenta.

Na versão iterativa, o número de iterações cresce com n.
Por isso, sua complexidade temporal é O(n), considerando cada
operação aritmética como uma operação de custo constante.

Para calcular Fibonacci com valores muito grandes de n e obter
resultados exatos, podemos utilizar números de precisão arbitrária.
Nesse caso, as operações ficam mais caras conforme os números
aumentam de tamanho.

Como o número de bits necessários para representar F(n) cresce
proporcionalmente a n, até mesmo armazenar e escrever o resultado
exige mais recursos conforme n aumenta.
*/

// ============================================================
// 4.4 - ANÁLISE DO PONTO C
// Origem algébrica da fórmula
// ============================================================

/*
A) FIBONACCI É UMA RECORRÊNCIA LINEAR HOMOGÊNEA

A sequência de Fibonacci é definida por:

F(n) = F(n - 1) + F(n - 2)

com F(0) = 0 e F(1) = 1.

Cada termo é calculado somando os dois termos anteriores.

Ela é chamada de linear porque os termos anteriores aparecem
multiplicados por constantes. É homogênea porque não existe
nenhum termo extra sendo somado à fórmula.

B) EQUAÇÃO CARACTERÍSTICA

Para encontrar uma fórmula que calcule Fibonacci diretamente,
consideramos uma solução do tipo F(n) = r^n e substituímos
na recorrência.

Assim:

r^n = r^(n - 1) + r^(n - 2)

Dividindo os dois lados por r^(n - 2), obtemos:

r^2 = r + 1

Reorganizando:

r^2 - r - 1 = 0

Essa é a equação característica da sequência de Fibonacci.

C) AS RAÍZES DA EQUAÇÃO

Resolvendo a equação característica, encontramos duas raízes:

phi = (1 + raiz(5)) / 2

psi = (1 - raiz(5)) / 2

Como as duas raízes são distintas, podemos escrever a solução
geral como uma combinação:

F(n) = A * phi^n + B * psi^n

Para descobrir A e B, utilizamos os valores iniciais
F(0) = 0 e F(1) = 1.

Para n = 0:

A + B = 0

Para n = 1:

A * phi + B * psi = 1

Resolvendo o sistema, obtemos:

A = 1 / raiz(5)
B = -1 / raiz(5)

Substituindo esses valores, chegamos à fórmula de Binet:

F(n) = (phi^n - psi^n) / raiz(5)

Essa fórmula permite calcular um termo da sequência
diretamente, sem precisar calcular todos os anteriores.

D) O MESMO RESULTADO USANDO MATRIZES

Também podemos representar a sequência de Fibonacci usando
a matriz:

A = [ [1, 1],
      [1, 0] ]

Com essa matriz, podemos escrever:

[F(n + 1), F(n)]^T = A^n * [1, 0]^T

Quando elevamos A à potência n, os elementos da matriz
resultante contêm termos da sequência de Fibonacci.

Para facilitar esse cálculo, podemos diagonalizar a matriz,
escrevendo:

A = P * D * P^-1

Nessa expressão, D é uma matriz diagonal cujos elementos
são os autovalores de A, e P contém os autovetores associados.

Os autovalores são encontrados pela equação característica
da matriz:

lambda^2 - lambda - 1 = 0

Essa é a mesma equação característica obtida a partir da
recorrência de Fibonacci. Portanto, os autovalores são phi
e psi.

Elevando a matriz à potência n, obtemos:

A^n = P * D^n * P^-1

Como D é diagonal, basta elevar cada elemento da diagonal
à potência n. Após realizar as multiplicações e considerar
as condições iniciais, chegamos novamente à fórmula de Binet.

Assim, a recorrência e a diagonalização de matrizes conduzem
à mesma expressão fechada para os números de Fibonacci.

E) BÔNUS: CÁLCULO PARA VALORES MUITO GRANDES

Podemos utilizar a exponenciação rápida de matrizes para
calcular Fibonacci de forma exata.

Esse método precisa de aproximadamente log2(n) etapas de
multiplicação de matrizes, sendo uma alternativa eficiente
para valores muito grandes de n.

Para manter o resultado exato, precisamos utilizar números
com precisão arbitrária e garantir que as operações não
sofram estouro de representação.
*/
