// Tarefa 01 - Natureza Numérica e Propriedades
/* Ideia do programa: pegar cada número de Fibonacci e dividir
pelo anterior. Quanto mais avançamos, mais o resultado se aproxima 
da Razão Áurea (phi ≈ 1.618). */

#include <iostream>
#include <string>   
#include <iomanip>    
#include <cmath>      

// prototipo 
void verificarRazaoAurea(int limite);

int main() {
    // Mostra as razões dos termos até n = 30    
    verificarRazaoAurea(30);
    return 0;
}

// definição
void verificarRazaoAurea(int limite) {

    /*phi tem uma fórmula pronta: (1 + raiz de 5) / 2
    usa esse valor como "gabarito" para comparar com as razões. */
    const double phi = (1.0 + std::sqrt(5.0)) / 2.0;

    //Configura a saída com 10 casas decimais
    std::cout << std::fixed << std::setprecision(10);
    std::cout << "phi = " << phi << "\n\n";

    //tabela
    std::cout << std::setw(4)  << "n"
              << std::setw(14) << "F(n)"
              << std::setw(14) << "F(n)/F(n-1)"
              << std::setw(16) << "|razao - phi|" << "\n";
    std::cout << std::string(48, '-') << "\n";   //separadora

    //começa definindo com os dois primeiros termos: F(1) = 1 e F(2) = 1.
    long long anterior = 1;
    long long atual = 1;

    for (int n = 2; n <= limite; ++n) {
        //divide o termo atual pelo anterior.
        double razao = static_cast<double>(atual) / static_cast<double>(anterior);

        // distancia de razão á phi
        double erro = std::abs(razao - phi);

        // Imprime na tabela
        std::cout << std::setw(4)  << n
                  << std::setw(14) << atual
                  << std::setw(14) << razao
                  << std::setw(16) << erro << "\n";

        // Avança na sequência somando os dois ultimos numero para formar o proximo
        long long proximo = atual + anterior;
        anterior = atual;   // a mão da esquerda pega o que estava na direita
        atual = proximo;    // a da direita pega o número novo
    }

}